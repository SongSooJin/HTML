// JavaScript Document


$(function(){
	
	$(document).on('keydown',function(e){
		if(e.keyCode == 13) return false;
		});
		
	$('#ssjid').on('keydown',function(e){
		if($('#ssjid').val() != "" && e.keyCode == 13)
			$('#ssjps').focus();			
		});	
		
	$('#ssjps').on('keydown',function(e){
		if($('#ssjps').val() != "" && e.keyCode == 13)
			$('#ssjpsCheck').focus();			
		});	
		
	$('#ssjpsCheck').on('keydown',function(e){
		if($('#ssjCheck').val() != "" && e.keyCode == 13)
			$('#ssjpsnick').focus();			
		});		
		
	$('#ssjnick').on('keydown',function(e){
		if($('#ssjnick').val() != "" && e.keyCode == 13)
			$('#ssjhp1').focus();			
		});	
		
	$('#ssjid').focus();
	
	$('input').on('focus',function(){
		$(this).css('background-color','#fdd7cd');
		});
		
	$('input').on('blur',function(){
		$(this).css('background-color','white');
		$(':submit',':resest').css('background-color','#fdd7cd');
	
	});
	

		$('#ssjhp1').on('keyup',function(){
			if($(this).val().length ==4)
				$('#ssjhp2').focus();
			});
			
		$('#ssjhp2').on('keyup',function(){
			if($(this).val().length ==4)
				$('#ssjhp3').focus();
			});		
			
					
		$('#ssjnewMemberForm').on('submit',function(){
		var ssjid = document.getElementById('ssjid');	
		if(ssjid.value == "") {
			alert("회원번호를 입력해 주세요");
			ssjid.focus();
			return false;
		}	
			
		if(ssjid.value.length < 6 || ssjid.value.length >8) {
		alert("회원번호는 6-8자로 입력하세요.");
		ssjid.value = "";
		ssjid.focus();
		return false;
		}
		
		var ssjps= document.getElementById('ssjps');
		var ssjpsCheck = document.getElementById('ssjpsCheck');
		
		var ssjid = document.getElementById('ssjid'); 
		
		if(ssjps.value == "") {
			alert("비밀번호를 입력해 주세요");
			ssjps.focus();
			return false;
		}
		
		if(ssjps.value != ssjpsCheck.value) {
			alert("비밀번호 확인이 일치하지 않습니다.");
			ssjpsCheck.value = "";
			ssjpsCheck.focus();
			return false;
		}
		
		var ssjnick = document.getElementById('ssjnick'); 
		
		if(ssjnick.value == "") {
			alert("닉네임을 입력해 주세요");
			ssjnick.focus();
			return false;
		}	
			
		if(!$('input[type="radio"]').is(':checked')){
			alert("나이를 선택하세요");
			return false;
			}
			
		if($('select').val()==""){
			alert("직업을 선택하세요")
			$('select').focus();
			return false;
			}
					
			
		if(!$('input[type="checkbox"]').is(':checked')){
			alert("관심장르는 1개 이상 선택하세요");
			return false;
			}		
			
	
			});
			
		});
	