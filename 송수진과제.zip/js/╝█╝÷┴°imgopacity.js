// JavaScript Document



$(function(){
	$('#op1').on('mouseover',function(){
		$('#op1').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op1').fadeTo(100,1);
			}
			);	
			
	$('#op2').on('mouseover',function(){
		$('#op2').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op2').fadeTo(100,1);
			}
			);	
			
	$('#op3').on('mouseover',function(){
		$('#op3').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op3').fadeTo(100,1);
			}
			);
			
	$('#op4').on('mouseover',function(){
		$('#op4').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op4').fadeTo(100,1);
			}
			);
			
	$('#op5').on('mouseover',function(){
		$('#op5').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op5').fadeTo(100,1);
			}
			);	
			
	$('#op6').on('mouseover',function(){
		$('#op6').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op6').fadeTo(100,1);
			}
			);	
			
	$('#op7').on('mouseover',function(){
		$('#op7').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op7').fadeTo(100,1);
			}
			);
			
	$('#op8').on('mouseover',function(){
		$('#op8').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op8').fadeTo(100,1);
			}
			);										

			
	$('#op9').on('mouseover',function(){
		$('#op9').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op9').fadeTo(100,1);
			}
			);
			
	$('#op10').on('mouseover',function(){
		$('#op10').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op10').fadeTo(100,1);
			}
			);										
			
	$('#op11').on('mouseover',function(){
		$('#op11').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op11').fadeTo(100,1);
			}
			);	
			
	$('#op12').on('mouseover',function(){
		$('#op12').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op12').fadeTo(100,1);
			}
			);	
			
	$('#op13').on('mouseover',function(){
		$('#op13').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op13').fadeTo(100,1);
			}
			);
			
	$('#op14').on('mouseover',function(){
		$('#op14').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op14').fadeTo(100,1);
			}
			);
			
	$('#op15').on('mouseover',function(){
		$('#op15').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op15').fadeTo(100,1);
			}
			);	
			
	$('#op16').on('mouseover',function(){
		$('#op16').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op16').fadeTo(100,1);
			}
			);	
								
	$('#op17').on('mouseover',function(){
		$('#op17').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op17').fadeTo(100,1);
			}
			);	
			
	$('#op18').on('mouseover',function(){
		$('#op18').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op18').fadeTo(100,1);
			}
			);	
			
	$('#op19').on('mouseover',function(){
		$('#op19').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op19').fadeTo(100,1);
			}
			);
			
	$('#op20').on('mouseover',function(){
		$('#op20').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op20').fadeTo(100,1);
			}
			);
			
	$('#op21').on('mouseover',function(){
		$('#op21').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op21').fadeTo(100,1);
			}
			);	
			
	$('#op22').on('mouseover',function(){
		$('#op22').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op22').fadeTo(100,1);
			}
			);	
			
	$('#op23').on('mouseover',function(){
		$('#op23').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op23').fadeTo(100,1);
			}
			);
			
	$('#op24').on('mouseover',function(){
		$('#op24').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op24').fadeTo(100,1);
			}
			);										

			
	$('#op25').on('mouseover',function(){
		$('#op25').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op25').fadeTo(100,1);
			}
			);
			
	$('#op26').on('mouseover',function(){
		$('#op26').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op26').fadeTo(100,1);
			}
			);																			
		
		
	$('#op27').on('mouseover',function(){
		$('#op27').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op27').fadeTo(100,1);
			}
			);
			
	$('#op28').on('mouseover',function(){
		$('#op28').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op28').fadeTo(100,1);
			}
			);					

			
	$('#op29').on('mouseover',function(){
		$('#op29').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op29').fadeTo(100,1);
			}
			);
			
	$('#op30').on('mouseover',function(){
		$('#op30').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op30').fadeTo(100,1);
			}
			);										
			
	$('#op31').on('mouseover',function(){
		$('#op31').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op31').fadeTo(100,1);
			}
			);	
			
	$('#op32').on('mouseover',function(){
		$('#op32').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op32').fadeTo(100,1);
			}
			);	
			
	$('#op33').on('mouseover',function(){
		$('#op33').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op33').fadeTo(100,1);
			}
			);
			
	$('#op34').on('mouseover',function(){
		$('#op34').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op34').fadeTo(100,1);
			}
			);
			
	$('#op35').on('mouseover',function(){
		$('#op35').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op35').fadeTo(100,1);
			}
			);	
			
	$('#op36').on('mouseover',function(){
		$('#op36').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op36').fadeTo(100,1);
			}
			);	
								
	$('#op37').on('mouseover',function(){
		$('#op37').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op37').fadeTo(100,1);
			}
			);	
			
	$('#op38').on('mouseover',function(){
		$('#op38').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op38').fadeTo(100,1);
			}
			);	
			
	$('#op39').on('mouseover',function(){
		$('#op39').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op39').fadeTo(100,1);
			}
			);
			
	$('#op40').on('mouseover',function(){
		$('#op40').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op40').fadeTo(100,1);
			}
			);
			
			
	$('#op41').on('mouseover',function(){
		$('#op41').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op41').fadeTo(100,1);
			}
			);	
			
	$('#op42').on('mouseover',function(){
		$('#op42').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op42').fadeTo(100,1);
			}
			);	
			
	$('#op43').on('mouseover',function(){
		$('#op43').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op43').fadeTo(100,1);
			}
			);
			
	$('#op44').on('mouseover',function(){
		$('#op44').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op44').fadeTo(100,1);
			}
			);
			
	$('#op45').on('mouseover',function(){
		$('#op45').fadeTo(100,0.5)
	})
		
	.on('mouseout',function(){
		$('#op45').fadeTo(100,1);
			}
			);			
			
			
					
});