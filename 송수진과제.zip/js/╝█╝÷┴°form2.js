// JavaScript Document


window.onload = function () {
	
	document.getElementById('ssjnewMemberForm').onsubmit = function() {
					
		var ssjid = document.getElementById('ssjid');	
		if(ssjid.value == "") {
			alert("회원번호를 입력해 주세요");
			ssjid.focus();
			return false;
		}	
			
		if(ssjid.value.length < 6 || ssjid.value.length >8) {
		alert("회원번호는 6-8자로 입력하세요.");
		ssjid.value = "";
		ssjid.focus();
		return false;
		}
		
		var ssjps= document.getElementById('ssjps');
		var ssjpsCheck = document.getElementById('ssjpsCheck');
		
		var ssjid = document.getElementById('ssjid'); 
		
		if(ssjps.value == "") {
			alert("비밀번호를 입력해 주세요");
			ssjps.focus();
			return false;
		}
		
		if(ssjps.value != ssjpsCheck.value) {
			alert("비밀번호 확인이 일치하지 않습니다.");
			ssjpsCheck.value = "";
			ssjpsCheck.focus();
			return false;
		}
		
	
			};
			
		};
	