// JavaScript Document

$(function() {
	$('.topsubMenuItem').slideUp(1);
	
	$('#topsubMenuBox').hide();
	
		var $topsubMenuItem = $('.topsubMenuItem');
		
		$('#topmenuItem li').each(function(index) {
			var newIndex = index -1;
			$(this).hover(
				function() {
					if(index > 0) {
						
				$('#topsubMenuBox').css('visibility','visible');
				$('#topsubMenuBox').show();
				
				$topsubMenuItem.eq(newIndex).slideDown(300);		
						}
					},
				function() {
					if(index > 0){
						
				$topsubMenuItem.eq(newIndex).slideUp(100);		
						}
					}
            	);
        	});
			
		$('.topsubMenuItem').hover(
			function() {
				$topsubMenuItem.stop();
				$('#topsubMenuBox').show();
				},
			function() {
				$topsubMenuItem.slideUp(1);
				$('#topsubMenuBox').hide();
				}		
			);	
	
	});
