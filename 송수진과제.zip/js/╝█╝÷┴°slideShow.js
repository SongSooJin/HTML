// JavaScript Document

$(function(){
	
	var movedIndex;
	
	function moveSlide(index) {
		movedIndex = index;
		
		var moveLeft = -(index*1200);
		$('#slidePanel').animate({'left':moveLeft},'slow');
	}
		
		var randomNumber = Math.floor(Math.random()*4);
		moveSlide(randomNumber);
		
		$('#prevButton').on('click',function(){
			if(movedIndex != 0)
				movedIndex = movedIndex -1;
				moveSlide(movedIndex);
			});
			
		$('#nextButton').on('click',function(){
			if(movedIndex != 3)
				movedIndex = movedIndex +1;
				moveSlide(movedIndex);
			});	
			
		setInterval(function(){
			if(movedIndex != 3 )
				movedIndex = movedIndex +1;
			else
				movedIndex = 0;
				
				moveSlide(movedIndex);
		},5000);
	

	
	var movedIndex2 = 0;
	
	function moveSlide2(index) {
		movedIndex2 = index;
		
		var moveLeft = -(index*260);
		$('#slidePanel2').animate({'left':moveLeft},'slow');
	}
		
		//var randomNumber2 = Math.floor(Math.random()*12);
		//moveSlide2(randomNumber2);
		
		$('#prevButton2').on('click',function(){
			if(movedIndex2 != 12)
				movedIndex2 = movedIndex2 +1;
				moveSlide2(movedIndex2);
			if (movedIndex2	>= 12 )
				movedIndex2 = 11;
			});
			
		$('#nextButton2').on('click',function(){
			if(movedIndex2 != 0)
				movedIndex2 = movedIndex2 -1;
			/*if (movedIndex2	<= 0 )
				movedIndex2 = 12;*/
				moveSlide2(movedIndex2);
			
			});	
		/*
		setInterval(function(){
			if(movedIndex2 != 12)
				movedIndex2 = movedIndex2 +1;
			else
				movedIndex2 = 0;
				
				moveSlide2(movedIndex2);
		},1000);*/
	
		var movedIndex3 = 0;
	
	function moveSlide3(index) {
		movedIndex3 = index;
		
		var moveLeft = -(index*260);
		$('#slidePanel3').animate({'left':moveLeft},'slow');
	}
		
		//var randomNumber2 = Math.floor(Math.random()*12);
		//moveSlide2(randomNumber2);
		
		$('#prevButton3').on('click',function(){
			if(movedIndex3 != 6)
				movedIndex3 = movedIndex3 +1;
				moveSlide3(movedIndex3);
			if (movedIndex3	>= 5 )
				movedIndex3 = 5;
			});
			
		$('#nextButton3').on('click',function(){
			if(movedIndex3 != 0)
				movedIndex3 = movedIndex3 -1;
			/*if (movedIndex2	<= 0 )
				movedIndex2 = 12;*/
				moveSlide3(movedIndex3);
			
			});	
	
	
			var movedIndex4 = 0;
	
	function moveSlide4(index) {
		movedIndex4 = index;
		
		var moveLeft = -(index*260);
		$('#slidePanel4').animate({'left':moveLeft},'slow');
	}
		
		//var randomNumber2 = Math.floor(Math.random()*12);
		//moveSlide2(randomNumber2);
		
		$('#prevButton4').on('click',function(){
			if(movedIndex4 != 4)
				movedIndex4 = movedIndex4 +1;
				moveSlide4(movedIndex4);
			if (movedIndex4	>= 3 )
				movedIndex4 = 3;
			});
			
		$('#nextButton4').on('click',function(){
			if(movedIndex4 != 0)
				movedIndex4 = movedIndex4 -1;
			/*if (movedIndex2	<= 0 )
				movedIndex2 = 12;*/
				moveSlide4(movedIndex4);
			
			});	
	
	
			var movedIndex5 = 0;
	
	function moveSlide5(index) {
		movedIndex5 = index;
		
		var moveLeft = -(index*260);
		$('#slidePanel5').animate({'left':moveLeft},'slow');
	}
		
		//var randomNumber2 = Math.floor(Math.random()*12);
		//moveSlide2(randomNumber2);
		
		$('#prevButton5').on('click',function(){
			if(movedIndex5 != 7)
				movedIndex5 = movedIndex5 +1;
				moveSlide5(movedIndex5);
			if (movedIndex5	>= 6 )
				movedIndex5 = 6;
			});
			
		$('#nextButton5').on('click',function(){
			if(movedIndex5 != 0)
				movedIndex5 = movedIndex5 -1;
			/*if (movedIndex2	<= 0 )
				movedIndex2 = 12;*/
				moveSlide5(movedIndex5);
			
			});	
	
	
	
	
	});	
	