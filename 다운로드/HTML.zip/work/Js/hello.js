console.log("Hello World");

// atom-runner 실행 단축키 : 컨트롤 +  r
// 외부에 설치된 node 컴파일러 사용하여 js 코드를 실행한다.
