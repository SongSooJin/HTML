// 한줄주석
/*
범위주석
*/

/**
다큐먼트 주석
*/

// js는 자바의 클래스가 없다

// 문법은 외우자
// 문법이 왜그럴까
// 자바는 철저하게 설계도
// class Strat {
//   Object global = new Object();
//
//   public static void main(String[] args) {
//     global.b = 100; //자바는 설계도
//     X x = new X();
// 200 Line code
//     x.print(10);
//    System.out.println(global.b);
//   }
// }

// class x {
  int a = 10;
  public void print (int a) {
    system.out.println(a);
  }
// }
// js는 파일메소드(자체)가 기동메소드(main)이다.
global.b = 100; // 설계도는 없어도돼,  하고싶은대로 해
// First class : js 객체는 일급 객체다.
// 
  constructor() {

  }
}
var a= 10;
function print(a) {
// 200 Line code
  console.log(a);
// alt + r :
}
